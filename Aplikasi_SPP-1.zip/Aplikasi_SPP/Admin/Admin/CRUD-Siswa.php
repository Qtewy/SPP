<?php
include "../Template-SPP/Header.php";
include "../Template-SPP/Navbar.php";
include "../Template-SPP/Sidebar.php";
?>     
        <!-- Main Content -->
        <div class="main-content" >
          <section class="section">
          <div class="row">
        <?php 
		if(isset($_GET['pesan'])){
		$pesan = $_GET['pesan'];
		if($pesan == "input"){
			echo "Data berhasil di input.";
		}else if($pesan == "update"){
			echo "Data berhasil di update.";
		}else if($pesan == "hapus"){
			echo "Data berhasil di hapus.";
		}
	    } ?>
        </div>
          <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Data Siswa</h4>
                        <a href="T_Siswa.php" class="btn btn-primary">Tambah Data Siswa</a>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive table-invoice">
                            <table class="table table-striped">
                                <tr>
                                    <th>NISN</th>
                                    <th>NIS</th>
                                    <th>Nama Siswa</th>
                                    <th>ID Kelas</th>
                                    <th>Alamat</th>
                                    <th>NO TELP</th>
                                    <th>ID SPP</th>
                                    <th>Action</th>
                                </tr>
                                <?php 
                                include "../koneksi.php";
                                $query_mysql = mysqli_query($koneksi,"select * from siswa");
                                $nomor = 1;
                                while($data = mysqli_fetch_array($query_mysql)){
                                ?>

                                <tr>
                                    <td class="font-weight-600"><?php echo $data['nisn']; ?></td>
                                    <td><?php echo $data['nis']; ?></td>
                                    <td>
                                        <div class="badge badge-warning"><?php echo $data['nama']; ?></div>
                                    </td>
                                    <td><?php echo $data['id_kelas']; ?></td>
                                    <td><?php echo $data['alamat']; ?></td>
                                    <td><?php echo $data['no_telp']; ?></td>
                                    <td><?php echo $data['id_spp']; ?></td>
                                    <td>
                                        <a href="E_Siswa.php?nisn=<?php echo $data['nisn']; ?>" class="btn btn-primary">Edit</a>
                                        <a href="H_Siswa.php?nisn=<?php echo $data['nisn']; ?>" class="btn btn-primary">Hapus</a>
                                    </td>
                                </tr>
                                <?php } ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
          </section>
        </div>
<?php include "../Template-SPP/Footer.php"; ?>      
