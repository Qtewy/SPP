<?php
include "../Template-SPP/Header.php";
include "../Template-SPP/Navbar.php";
include "../Template-SPP/Sidebar.php";
?>     
        <!-- Main Content -->
        <div class="main-content" >
          <section class="section">
            <div class="row">
              <div class="col-sm-12">
                <div class="card card-statistic-2">
                  <div class="card-stats">
                    <div class="card-stats-title">
                      <center><h1>Data Petugas</h1><center> 
                    </div>
                  </div>
                  <div class="card-wrap">
                    <div class="card-header">
                      <h4>Total Petugas</h4>
                    </div>
                    <div class="card-body">3</div>
                  </div>
                </div>
              </div>
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Data Petugas</h4>
                  </div>
                  <div class="card-body p-0">
                    <div class="table-responsive table-invoice">
                      <table class="table table-striped">
                        <tr>
                          <th>#</th>
                          <th>Kelas</th>
                          <th>Nama Petugas</th>
                          <th>Action</th>
                        </tr>
                        <tr>
                          <td><a href="#">1</a></td>
                          <td><div class="badge badge-success">XI RPL 1</div></td>
                          <td class="font-weight-600">Pa Asep</td>
                          <td><div class="product-cta">
                              <a href="#" class="btn btn-primary">Detail</a>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td><a href="#">2</a></td>
                          <td><div class="badge badge-success">XI RPL 1</div></td>
                          <td class="font-weight-600">Bu Niken</td>
                          <td><div class="product-cta">
                              <a href="#" class="btn btn-primary">Detail</a>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td><a href="#">3</a></td>
                          <td><div class="badge badge-warning">XI RPL 2</div></td>
                          <td class="font-weight-600">Pa Amir</td>
                          <td><div class="product-cta">
                              <a href="#" class="btn btn-primary">Detail</a>
                            </div>
                           </td>
                        </tr>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
          </section>
        </div>
<?php include "../Template-SPP/Footer.php"; ?>      
