<?php
include "../Template-SPP/Header.php";
include "../Template-SPP/Navbar.php";
include "../Template-SPP/Sidebar.php";
?>     
        <!-- Main Content -->
<body>
        <div class="main-content">
          <section class="section">
            <div class="row">
              <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="card card-statistic-2">
                  <div class="card-stats">
                    <div class="card-stats-title">
                      Data Siswa 
                    </div>
                  </div>
                  <div class="card-icon shadow-primary bg-primary">
                    <i class="fas fa-archive"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="card-header">
                      <h4>Total Siswa</h4>
                    </div>
                    <div class="card-body">3</div>
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="card card-statistic-2">
                  <div class="card-stats">
                    <div class="card-stats-title">
                      Data Kelas 
                    </div>
                  </div>
                  <div class="card-icon shadow-primary bg-primary">
                    <i class="fas fa-archive"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="card-header">
                      <h4>Total Kelas</h4>
                    </div>
                    <div class="card-body">3</div>
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="card card-statistic-2">
                  <div class="card-stats">
                    <div class="card-stats-title">
                      Data SPP 
                    </div>
                  </div>
                  <div class="card-icon shadow-primary bg-primary">
                    <i class="fas fa-archive"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="card-header">
                      <h4>Total SPP</h4>
                    </div>
                    <div class="card-body">1</div>
                  </div>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="card card-statistic-2">
                  <div class="card-stats">
                    <div class="card-stats-title">
                      Data Transanksi Bulanan 
                    </div>
                  </div>
                  <div class="card-icon shadow-primary bg-primary">
                    <i class="fas fa-archive"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="card-header">
                      <h4>Total Transanksi Bulanan </h4>
                    </div>
                    <div class="card-body">59</div>
                  </div>
                </div>
              </div>
              <div class="col-sm-6">
                <div class="card card-statistic-2">
                  <div class="card-stats">
                    <div class="card-stats-title">
                      Data Transanksi Tahunan 
                    </div>
                  </div>
                  <div class="card-icon shadow-primary bg-primary">
                    <i class="fas fa-archive"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="card-header">
                      <h4>Total Transanksi Tahunan</h4>
                    </div>
                    <div class="card-body">59</div>
                  </div>
                </div>
              </div>
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Data Transanksi Pembayaran SPP</h4>
                  </div>
                  <div class="card-body p-0">
                    <div class="table-responsive table-invoice">
                      <table class="table table-striped">
                        <tr>
                          <th>#</th>
                          <th>NISN</th>
                          <th>Nama Siswa</th>
                          <th>Tanggal Bayar</th>
                          <th>Jumlah bayar</th>
                          <th>Petugas</th>
                        </tr>
                        <tr>
                          <td><a href="#">1</a></td>
                          <td>20230122</td>
                          <td class="font-weight-600">Budi Jordan</td>
                          <td>2023-02-17</td>
                          <td>200000</td>
                          <td><div class="badge badge-success">Pa Asep</div></td>
                        </tr>
                        <tr>
                          <td><a href="#">2</a></td>
                          <td>20231103</td>
                          <td class="font-weight-600">Nirmala Fitri Raya</td>
                          <td>2023-11-03</td>
                          <td>300000</td>
                          <td><div class="badge badge-success">Bu Niken</div></td>
                        </tr>
                        <tr>
                          <td><a href="#">3</a></td>
                          <td>20230712</td>
                          <td class="font-weight-600">Axel Miracle</td>
                          <td>2023-07-12</td>
                          <td>200000</td>
                          <td><div class="badge badge-success">Pa Asep</div></td>
                        </tr>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
          </section>
        </div>
<?php include "../Template-SPP/Footer.php"; ?>      
